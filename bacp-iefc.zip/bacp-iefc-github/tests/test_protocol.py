import pytest
from bacp.protocol import BACP_IeFC, Device, FogNode
from bacp.ledger import PermissionedPoALedger


@pytest.fixture
def system():
    p = BACP_IeFC(PermissionedPoALedger(batch_size=10))
    p.add_fog(FogNode.create("fog-a"))
    p.add_fog(FogNode.create("fog-b"))
    a = Device.create("A", "fog-a")
    b = Device.create("B", "fog-a")
    c = Device.create("C", "fog-b")
    for d in (a, b, c):
        p.register_device(d)
    return p, a, b, c


def test_intra_fog_authentication(system):
    p, a, b, _ = system
    result = p.authenticate(a.device_id, b.device_id, "intra-fog")
    assert result["authenticated"] and result["access_granted"]
    assert result["session_key_match"]
    assert len(result["session_key_hex"]) == 64


def test_inter_fog_authentication(system):
    p, a, _, c = system
    result = p.authenticate(a.device_id, c.device_id, "inter-fog")
    assert result["authenticated"] and result["mode"] == "inter-fog"


def test_mobile_authentication(system):
    p, a, _, c = system
    result = p.authenticate(c.device_id, a.device_id, "mobile")
    assert result["authenticated"] and result["mode"] == "mobile"


def test_mode_mismatch_rejected(system):
    p, a, _, c = system
    with pytest.raises(ValueError):
        p.authenticate(a.device_id, c.device_id, "intra-fog")


def test_duplicate_registration_rejected(system):
    p, a, _, _ = system
    with pytest.raises(ValueError):
        p.register_device(a)


def test_ledger_integrity(system):
    p, a, b, _ = system
    p.authenticate(a.device_id, b.device_id)
    assert p.ledger.verify_chain()


def test_unknown_device_rejected(system):
    p, a, _, _ = system
    with pytest.raises(KeyError):
        p.authenticate(a.device_id, "missing-device")
