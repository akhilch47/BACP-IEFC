# BACP-IeFC — Blockchain-Based Access Control Protocol for IoT-Enabled Fog Computing

A runnable, research-oriented reference implementation based on:

**Akhil Chaurasia, Alok Kumar, Udai Pratap Rao**, “BACP-IeFC: designing blockchain-based access control protocol in IoT-enabled fog computing environment,” *Cluster Computing* 27 (2024), 13919–13944.  
DOI: [10.1007/s10586-024-04656-4](https://doi.org/10.1007/s10586-024-04656-4)

## What's included

- Edge-device registration with fog-node association.
- P-256 elliptic-curve public/private key pairs.
- ECDSA challenge/response signatures and ECDH shared-secret agreement.
- SHA-512 hash-chain-derived, time-limited per-device-pair key metadata.
- Intra-fog authentication.
- Inter-fog authentication.
- Roaming/mobile-device authentication path.
- Permissioned append-only ledger with a rotating Proof-of-Authority validator set.
- Solidity registry contract for deployment to an EVM-compatible development chain.
- Performance experiment runner, CSV/JSON output, and latency plots.
- Automated tests.

## Quick start

Requires Python 3.10 or later.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
pip install -e ".[dev]"
pytest -q
```

Run the protocol demonstration:

```bash
bacp-iefc demo
# or
python -m bacp.cli demo
```

Run a performance experiment:

```bash
bacp-iefc experiment --devices 100 --auth-rounds 500 --output results
```

The experiment writes:
- `results/experiment_summary.json`
- `results/measurements.csv`
- `results/authentication_latency.png` (when matplotlib is installed)
- `results/registration_latency.png` (when matplotlib is installed)

## Architecture

```text
Edge device A  <---- signed challenge / response ---->  Fog node(s)
      |                                                   |
      +------------- ECDH session agreement --------------+
                                                          |
                                                   PoA permissioned
                                                      ledger
                                                          |
                                               Device and key metadata
```

### Protocol flow

1. A device creates a P-256 key pair and registers its public key and fog-node identifier.
2. The requester asks its fog node to authenticate a recipient.
3. The fog-mediated handshake uses fresh nonces, a timestamp, and ECDSA signatures from both endpoints.
4. For inter-fog and mobile modes, the protocol checks the registered fog-node route and uses the same authenticated endpoint handshake.
5. The fog node derives a time-scoped hash-chain key pair for the requester/recipient pair. The ledger stores the public key and fingerprint, never the plaintext private key.
6. Both endpoints independently compute ECDH and derive the same 256-bit session key using HKDF-SHA512, both nonces, the hash-chain public key, and a context string.
7. The successful authentication metadata is committed to the local PoA ledger.

## Mapping to the paper

| Paper component | Implementation |
|---|---|
| Section 3.4.1 ECC | `bacp/crypto.py`: P-256 |
| Section 3.4.2 SHA-512 hash chain | `hash_chain()` and `hashchain_scalar()` |
| Section 3.4.4 permissioned blockchain / PoA | `bacp/ledger.py` |
| Section 3.5.1 device registration | `BACP_IeFC.register_device()` |
| Algorithm 1: intra-fog authentication | `BACP_IeFC.authenticate(..., "intra-fog")` |
| Algorithms 2–3: hash-chain key and session key | `_get_or_create_hashchain_record()` and `derive_session_key()` |
| Algorithms 4–5: inter-fog authentication/key lifecycle | `authenticate(..., "inter-fog")` |
| Mobile / roaming communication | `authenticate(..., "mobile")` |
| Algorithm 6: blockchain transaction/block handling | `PermissionedPoALedger` |
| Algorithm 7: contract-side registration and access records | `contracts/BACPRegistry.sol` |
| Section 5: performance analysis | `bacp/experiments.py` |

## Important reproducibility and security notes

This repository is a **reference implementation**, not a byte-for-byte reproduction of the original MIRACL/Truffle experiment environment.

The paper contains notation and implementation ambiguities that require explicit engineering decisions:
- Some printed equations use inconsistent symbols for the hash-chain private/public key and session key.
- The mobile-device section describes roaming and refers back to the inter-fog algorithms, rather than providing a complete independent message-by-message algorithm.
- The paper's communication-cost discussion reports different totals in different locations (e.g., Table 9 reports 3328 bits, while the surrounding prose calculates a separate mobile total of 3640 bits).
- The paper describes an Ethereum 2.0 / PoA deployment and also uses Ganache/Truffle terminology. This repository provides a local PoA ledger emulator plus an EVM Solidity registry contract; it does not claim to recreate the authors' original chain configuration.

For a safe executable protocol, this implementation makes the following choices:
- ECDSA is used for message authentication and ECDH for endpoint key agreement on P-256.
- HKDF-SHA512 derives the final session key from the ECDH secret and fresh nonces. This avoids treating public values or transmitted hashes as secret key material.
- The hash-chain-derived private scalar remains fog-side; only public key material and a fingerprint/expiry record are placed in the ledger. The paper's transaction is described as encrypted to the fog node, but plaintext private keys should never be written to a public or replicated ledger.
- The local PoA ledger is a simulation. It rotates among configured trusted validators and hash-links committed blocks; it is not a consensus implementation for production multi-host networks.
- The Solidity contract stores public metadata and emits events. It is not deployed automatically by the Python demo.

These are deliberate, documented implementation interpretations. They should not be described as proof that every security claim in the paper has been formally re-proved. Formal ProVerif verification is not included in this initial codebase.

## Paper-reported reference values

The paper reports the following values in its experimental setup. They are included as comparison targets in `experiment_summary.json`; they are **not hard-coded as measured results**.

| Metric | Paper-reported value |
|---|---:|
| Edge/fog computation overhead | 5.539 ms |
| Mobile communication computation overhead | 6.233 ms |
| Communication overhead (Table 9) | 3328 bits |
| Mobile communication overhead | 3640 bits |
| Edge registration response time | 56.3 ms |
| Average transaction issue time | 0.0005 s |
| Energy due to communication overhead | 1198.08 µJ |
| Simulated edge devices | 500 |
| Average block batch size | 100 transactions |

The local Python timing results will depend on your CPU, Python version, cryptography backend, and runtime load. They are not directly comparable to the paper's MIRACL measurements unless the environment and operation definitions are matched.

## Solidity contract

`contracts/BACPRegistry.sol` is an EVM-compatible registry contract. It supports:
- owner-managed validator allowlist;
- validator-only device registration;
- validator-only publication of time-limited pair-key public metadata;
- public read methods for registered device and pair-key metadata;
- validator-only authentication event recording.

It targets Solidity `^0.8.20`. Compile/deploy it using your preferred EVM development toolchain (e.g., Remix, Hardhat, or Foundry). The Python demo does not require a blockchain node.

## Repository structure

```text
bacp-iefc-github/
├── bacp/
│   ├── __init__.py
│   ├── crypto.py
│   ├── ledger.py
│   ├── protocol.py
│   ├── experiments.py
│   └── cli.py
├── contracts/
│   └── BACPRegistry.sol
├── scripts/
│   └── run_demo.py
├── tests/
│   └── test_protocol.py
├── pyproject.toml
├── README.md
└── LICENSE
```

## License

MIT. See `LICENSE`.
