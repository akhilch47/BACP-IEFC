// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title BACP-IeFC permissioned registry (public metadata only)
/// @notice Stores registered device public keys and hash-chain key metadata.
///         Do NOT store plaintext private keys or session keys on-chain.
contract BACPRegistry {
    address public owner;
    mapping(address => bool) public validators;

    struct DeviceRecord {
        bytes publicKey;
        bytes32 fogId;
        bool registered;
    }

    struct PairKeyRecord {
        bytes publicKey;
        bytes32 fingerprint;
        uint64 expiresAt;
        bool exists;
    }

    mapping(bytes32 => DeviceRecord) private devices;
    mapping(bytes32 => PairKeyRecord) private pairKeys;

    event DeviceRegistered(bytes32 indexed deviceId, bytes32 indexed fogId);
    event PairKeyPublished(bytes32 indexed requester, bytes32 indexed recipient,
                           bytes32 fingerprint, uint64 expiresAt);
    event AuthenticationRecorded(bytes32 indexed requester, bytes32 indexed recipient,
                                  bytes32 indexed transcriptHash, uint64 timestamp);

    modifier onlyOwner() {
        require(msg.sender == owner, "owner only");
        _;
    }

    modifier onlyValidator() {
        require(validators[msg.sender], "validator only");
        _;
    }

    constructor(address[] memory initialValidators) {
        owner = msg.sender;
        for (uint256 i = 0; i < initialValidators.length; i++) {
            validators[initialValidators[i]] = true;
        }
    }

    function setValidator(address account, bool enabled) external onlyOwner {
        validators[account] = enabled;
    }

    function registerDevice(bytes32 deviceId, bytes calldata publicKey,
                             bytes32 fogId) external onlyValidator {
        require(deviceId != bytes32(0), "empty device id");
        require(publicKey.length > 0, "empty public key");
        require(!devices[deviceId].registered, "already registered");
        devices[deviceId] = DeviceRecord(publicKey, fogId, true);
        emit DeviceRegistered(deviceId, fogId);
    }

    function getDevice(bytes32 deviceId)
        external view returns (bytes memory publicKey, bytes32 fogId, bool registered)
    {
        DeviceRecord storage d = devices[deviceId];
        return (d.publicKey, d.fogId, d.registered);
    }

    function publishPairKey(bytes32 requester, bytes32 recipient,
                            bytes calldata publicKey, bytes32 fingerprint,
                            uint64 expiresAt) external onlyValidator {
        require(devices[requester].registered && devices[recipient].registered,
                "devices must be registered");
        require(expiresAt > block.timestamp, "expired key");
        bytes32 pairId = keccak256(abi.encodePacked(requester, recipient));
        pairKeys[pairId] = PairKeyRecord(publicKey, fingerprint, expiresAt, true);
        emit PairKeyPublished(requester, recipient, fingerprint, expiresAt);
    }

    function getPairKey(bytes32 requester, bytes32 recipient)
        external view returns (bytes memory publicKey, bytes32 fingerprint,
                              uint64 expiresAt, bool valid)
    {
        PairKeyRecord storage p = pairKeys[keccak256(abi.encodePacked(requester, recipient))];
        valid = p.exists && p.expiresAt > block.timestamp;
        return (p.publicKey, p.fingerprint, p.expiresAt, valid);
    }

    function recordAuthentication(bytes32 requester, bytes32 recipient,
                                  bytes32 transcriptHash) external onlyValidator {
        require(devices[requester].registered && devices[recipient].registered,
                "unknown device");
        emit AuthenticationRecorded(requester, recipient, transcriptHash,
                                     uint64(block.timestamp));
    }
}
