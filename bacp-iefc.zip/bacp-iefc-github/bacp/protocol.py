"""BACP-IeFC protocol orchestration for intra-fog, inter-fog and roaming devices.

The implementation follows the paper's registration, challenge/response,
fog-mediated authorization, hash-chain key lifecycle and session establishment.
Where the paper's equations are ambiguous/inconsistent, see README.md.
"""
from __future__ import annotations

import hashlib
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

from .crypto import (
    CURVE, derive_session_key, ecdh, hashchain_scalar, public_bytes,
    random_nonce, sign, verify, load_public, generate_device_keypair,
)
from .ledger import PermissionedPoALedger


@dataclass
class Device:
    device_id: str
    fog_id: str
    private_key: ec.EllipticCurvePrivateKey
    public_key: ec.EllipticCurvePublicKey

    @classmethod
    def create(cls, device_id: str, fog_id: str):
        private = generate_device_keypair()
        return cls(device_id, fog_id, private, private.public_key())

    def sign(self, message: bytes) -> bytes:
        return sign(self.private_key, message)

    def export_public_hex(self) -> str:
        return public_bytes(self.public_key).hex()


@dataclass
class FogNode:
    fog_id: str
    secret: bytes
    key_lifetime_seconds: int = 3600

    @classmethod
    def create(cls, fog_id: str, key_lifetime_seconds: int = 3600):
        return cls(fog_id, secrets.token_bytes(32), key_lifetime_seconds)


class BACP_IeFC:
    def __init__(self, ledger: PermissionedPoALedger | None = None,
                 timestamp_skew_seconds: int = 60):
        self.ledger = ledger or PermissionedPoALedger()
        self.timestamp_skew_seconds = timestamp_skew_seconds
        self.devices: dict[str, Device] = {}
        self.fog_nodes: dict[str, FogNode] = {}
        self.metrics: list[dict[str, Any]] = []

    def add_fog(self, fog: FogNode) -> None:
        if fog.fog_id in self.fog_nodes:
            raise ValueError(f"Fog node already exists: {fog.fog_id}")
        self.fog_nodes[fog.fog_id] = fog

    def register_device(self, device: Device) -> float:
        start = time.perf_counter()
        if device.fog_id not in self.fog_nodes:
            raise ValueError(f"Unknown fog node: {device.fog_id}")
        self.ledger.register_device(
            device.device_id, device.export_public_hex(), device.fog_id
        )
        self.devices[device.device_id] = device
        self.ledger.commit(force=True)
        elapsed_ms = (time.perf_counter() - start) * 1000
        self.metrics.append({"operation": "registration", "device": device.device_id,
                             "latency_ms": elapsed_ms})
        return elapsed_ms

    @staticmethod
    def _transcript(a: str, b: str, fog_a: str, fog_b: str,
                    nonce_a: bytes, nonce_b: bytes, challenge: bytes,
                    timestamp: float, mode: str) -> bytes:
        fields = [a, b, fog_a, fog_b, mode, nonce_a.hex(), nonce_b.hex(),
                  challenge.hex(), f"{timestamp:.6f}"]
        return json.dumps(fields, separators=(",", ":")).encode()

    def _valid_timestamp(self, timestamp: float) -> bool:
        return abs(time.time() - timestamp) <= self.timestamp_skew_seconds

    def _get_or_create_hashchain_record(self, requester: str, recipient: str,
                                        fog: FogNode, now: float):
        record = self.ledger.get_valid_key_record(requester, recipient, now)
        if record:
            return record
        epoch = int(now // fog.key_lifetime_seconds)
        scalar = hashchain_scalar(requester, recipient, epoch, fog.secret)
        private = ec.derive_private_key(scalar, CURVE)
        pub_hex = public_bytes(private.public_key()).hex()
        fingerprint = hashlib.sha512(bytes.fromhex(pub_hex)).hexdigest()
        expires = (epoch + 1) * fog.key_lifetime_seconds
        self.ledger.put_key_record(requester, recipient, pub_hex, fingerprint, expires)
        return self.ledger.get_valid_key_record(requester, recipient, now)

    def authenticate(self, requester_id: str, recipient_id: str,
                     mode: str = "auto") -> dict[str, Any]:
        """Authenticate two registered devices and return a shared session key.

        mode: auto | intra-fog | inter-fog | mobile. 'mobile' models a roaming
        requester using the recipient's registered fog as the destination route.
        """
        start = time.perf_counter()
        if requester_id == recipient_id:
            raise ValueError("Requester and recipient must be different devices")
        a = self.devices[requester_id]
        b = self.devices[recipient_id]
        self.ledger.get_device(requester_id)
        self.ledger.get_device(recipient_id)

        same_fog = a.fog_id == b.fog_id
        if mode == "auto":
            mode = "intra-fog" if same_fog else "inter-fog"
        if mode == "intra-fog" and not same_fog:
            raise ValueError("intra-fog mode requires devices on the same fog node")
        if mode == "inter-fog" and same_fog:
            raise ValueError("inter-fog mode requires different fog nodes")
        if mode not in {"intra-fog", "inter-fog", "mobile"}:
            raise ValueError("Unsupported communication mode")

        fog_a = self.fog_nodes[a.fog_id]
        fog_b = self.fog_nodes[b.fog_id]
        nonce_a, nonce_b, challenge = random_nonce(), random_nonce(), random_nonce()
        issued_at = time.time()
        transcript = self._transcript(
            requester_id, recipient_id, a.fog_id, b.fog_id,
            nonce_a, nonce_b, challenge, issued_at, mode
        )

        # Algorithm 1/4 challenge-response: both edge endpoints sign the
        # same fresh transcript; fog nodes verify against registered keys.
        sig_a = a.sign(transcript + b"|A")
        sig_b = b.sign(transcript + b"|B")
        if not self._valid_timestamp(issued_at):
            raise PermissionError("Expired authentication timestamp")
        if not verify(a.public_key, sig_a, transcript + b"|A"):
            raise PermissionError("Requester signature verification failed")
        if not verify(b.public_key, sig_b, transcript + b"|B"):
            raise PermissionError("Recipient signature verification failed")

        # Cross-fog forwarding is authenticated by the registered fog IDs.
        if mode in {"inter-fog", "mobile"}:
            if a.fog_id not in self.fog_nodes or b.fog_id not in self.fog_nodes:
                raise PermissionError("Unknown fog node in inter-fog route")

        now = time.time()
        key_record = self._get_or_create_hashchain_record(
            requester_id, recipient_id, fog_a, now
        )
        hashchain_public = bytes.fromhex(key_record["hashchain_public_key"])

        # Each endpoint independently computes the same ECDH secret.
        shared_a = ecdh(a.private_key, b.public_key)
        shared_b = ecdh(b.private_key, a.public_key)
        if shared_a != shared_b:
            raise RuntimeError("ECDH agreement failed")
        context = f"{requester_id}|{recipient_id}|{mode}".encode()
        session_a = derive_session_key(shared_a, nonce_a, nonce_b,
                                       hashchain_public, context)
        session_b = derive_session_key(shared_b, nonce_a, nonce_b,
                                       hashchain_public, context)
        if session_a != session_b:
            raise RuntimeError("Session key confirmation failed")

        # Ledger records only public metadata/fingerprint; secret material is
        # never written in plaintext to an immutable public transaction.
        self.ledger.submit({
            "type": "AUTHENTICATION_SUCCESS", "requester": requester_id,
            "recipient": recipient_id, "mode": mode,
            "fog_a": a.fog_id, "fog_b": b.fog_id,
            "transcript_hash": hashlib.sha512(transcript).hexdigest(),
            "hashchain_fingerprint": key_record["fingerprint"],
            "key_expires_at": key_record["expires_at"],
            "timestamp": now,
        })
        self.ledger.commit(force=True)
        elapsed_ms = (time.perf_counter() - start) * 1000
        self.metrics.append({"operation": "authentication", "mode": mode,
                             "requester": requester_id, "recipient": recipient_id,
                             "latency_ms": elapsed_ms})
        return {
            "authenticated": True, "access_granted": True, "mode": mode,
            "requester": requester_id, "recipient": recipient_id,
            "session_key_hex": session_a.hex(),
            "session_key_match": session_a == session_b,
            "hashchain_key_fingerprint": key_record["fingerprint"],
            "key_expires_at": key_record["expires_at"],
            "latency_ms": elapsed_ms,
            "block_height": len(self.ledger.blocks),
        }

    def export_metrics(self) -> dict[str, Any]:
        return {"measurements": self.metrics, "summary": summarize_metrics(self.metrics)}


def summarize_metrics(metrics: list[dict[str, Any]]) -> dict[str, Any]:
    groups: dict[str, list[float]] = {}
    for item in metrics:
        groups.setdefault(item["operation"], []).append(float(item["latency_ms"]))
    return {
        name: {
            "count": len(values),
            "mean_ms": sum(values) / len(values),
            "min_ms": min(values),
            "max_ms": max(values),
        }
        for name, values in groups.items()
    }
