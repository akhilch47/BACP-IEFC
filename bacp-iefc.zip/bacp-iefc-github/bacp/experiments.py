"""Reproducible performance experiments and plots."""
from __future__ import annotations
import csv
import json
import random
import statistics
import time
from pathlib import Path

from .protocol import BACP_IeFC, Device, FogNode
from .ledger import PermissionedPoALedger


def run_experiment(output_dir: str = "results", devices: int = 50,
                   auth_rounds: int = 100, seed: int = 7) -> dict:
    random.seed(seed)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ledger = PermissionedPoALedger(
        validators=["fog-validator-1", "fog-validator-2", "fog-validator-3"],
        batch_size=100
    )
    protocol = BACP_IeFC(ledger)
    for i in range(3):
        protocol.add_fog(FogNode.create(f"fog-{i}"))

    ids = []
    for i in range(devices):
        device = Device.create(f"edge-{i:04d}", f"fog-{i % 3}")
        protocol.register_device(device)
        ids.append(device.device_id)

    auth_results = []
    for _ in range(auth_rounds):
        a, b = random.sample(ids, 2)
        mode = "auto"
        try:
            result = protocol.authenticate(a, b, mode)
            auth_results.append(result)
        except Exception as exc:
            auth_results.append({"authenticated": False, "error": str(exc)})

    metrics = protocol.export_metrics()
    summary = {
        "configuration": {"devices": devices, "auth_rounds": auth_rounds,
                          "seed": seed, "validators": ledger.validators},
        "protocol_metrics": metrics,
        "authentication_successes": sum(x.get("authenticated", False) for x in auth_results),
        "authentication_attempts": len(auth_results),
        "ledger_blocks": len(ledger.blocks),
        "ledger_integrity": ledger.verify_chain(),
        "paper_reference_targets": {
            "edge_fog_computation_ms": 5.539,
            "mobile_computation_ms": 6.233,
            "communication_bits_paper_table_9": 3328,
            "mobile_communication_bits_paper": 3640,
            "registration_response_ms_reported": 56.3,
            "transaction_issue_seconds_reported": 0.0005,
            "note": "Reference values reported by the paper; local Python measurements are not expected to match MIRACL/Truffle hardware results."
        }
    }
    (out / "experiment_summary.json").write_text(json.dumps(summary, indent=2))
    with (out / "measurements.csv").open("w", newline="") as f:
        rows = metrics["measurements"]
        writer = csv.DictWriter(f, fieldnames=sorted({k for r in rows for k in r}))
        writer.writeheader()
        writer.writerows(rows)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        auth_times = [m["latency_ms"] for m in metrics["measurements"]
                      if m["operation"] == "authentication"]
        reg_times = [m["latency_ms"] for m in metrics["measurements"]
                     if m["operation"] == "registration"]
        for values, title, filename, ylabel in [
            (auth_times, "BACP-IeFC Authentication Latency", "authentication_latency.png", "Latency (ms)"),
            (reg_times, "BACP-IeFC Device Registration Latency", "registration_latency.png", "Latency (ms)")
        ]:
            if values:
                plt.figure()
                plt.plot(range(1, len(values) + 1), values, marker=".")
                plt.title(title)
                plt.xlabel("Operation")
                plt.ylabel(ylabel)
                plt.tight_layout()
                plt.savefig(out / filename, dpi=160)
                plt.close()
    except ImportError:
        summary["plot_note"] = "Install matplotlib to generate plots."
        (out / "experiment_summary.json").write_text(json.dumps(summary, indent=2))
    return summary
