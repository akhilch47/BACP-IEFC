from __future__ import annotations
import argparse
import json
from .protocol import BACP_IeFC, Device, FogNode
from .experiments import run_experiment


def demo():
    protocol = BACP_IeFC()
    protocol.add_fog(FogNode.create("fog-west"))
    protocol.add_fog(FogNode.create("fog-east"))
    alice = Device.create("sensor-alice", "fog-west")
    bob = Device.create("sensor-bob", "fog-west")
    carol = Device.create("mobile-carol", "fog-east")
    for d in (alice, bob, carol):
        protocol.register_device(d)
    results = [
        protocol.authenticate(alice.device_id, bob.device_id, "intra-fog"),
        protocol.authenticate(alice.device_id, carol.device_id, "inter-fog"),
        protocol.authenticate(carol.device_id, alice.device_id, "mobile"),
    ]
    print(json.dumps({"demo": results, "ledger_valid": protocol.ledger.verify_chain()},
                     indent=2))


def main():
    parser = argparse.ArgumentParser(description="BACP-IeFC reference implementation")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("demo", help="run intra-fog, inter-fog and mobile demonstrations")
    exp = sub.add_parser("experiment", help="run performance experiment")
    exp.add_argument("--devices", type=int, default=50)
    exp.add_argument("--auth-rounds", type=int, default=100)
    exp.add_argument("--output", default="results")
    args = parser.parse_args()
    if args.command == "demo":
        demo()
    elif args.command == "experiment":
        print(json.dumps(run_experiment(args.output, args.devices, args.auth_rounds), indent=2))


if __name__ == "__main__":
    main()
