"""Cryptographic primitives used by the BACP-IeFC reference implementation.

Uses NIST P-256 ECDSA/ECDH and SHA-512. The paper's printed equations contain
ambiguous notation; this module makes the operational choices explicit.
"""
from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass
from typing import Iterable

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.exceptions import InvalidSignature

CURVE = ec.SECP256R1()
CURVE_ORDER = int(
    "FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551", 16
)


def sha512(data: bytes) -> bytes:
    return hashlib.sha512(data).digest()


def hash_chain(seed: bytes, count: int = 10) -> list[bytes]:
    """Return H(seed), H²(seed), ... H^count(seed), in forward order."""
    if count < 1:
        raise ValueError("count must be >= 1")
    out, value = [], seed
    for _ in range(count):
        value = sha512(value)
        out.append(value)
    return out


def hashchain_scalar(identity: str, peer_identity: str, epoch: int, fog_secret: bytes) -> int:
    """Derive a deterministic, nonzero P-256 scalar from a fog-held secret.

    The seed is domain-separated and pair-specific. The private scalar is kept
    by the fog service; only its public point/fingerprint is put in the ledger.
    """
    material = b"|".join([
        b"BACP-IeFC/hash-chain/v1", fog_secret, identity.encode(),
        peer_identity.encode(), str(epoch).encode()
    ])
    chain = hash_chain(material, 8)
    scalar = int.from_bytes(sha512(b"".join(chain)), "big") % (CURVE_ORDER - 1) + 1
    return scalar


def public_bytes(public_key: ec.EllipticCurvePublicKey) -> bytes:
    return public_key.public_bytes(
        serialization.Encoding.X962,
        serialization.PublicFormat.CompressedPoint,
    )


def load_public(data: bytes) -> ec.EllipticCurvePublicKey:
    return ec.EllipticCurvePublicKey.from_encoded_point(CURVE, data)


def generate_device_keypair():
    """Generate a long-term P-256 keypair used for ECDSA and ECDH."""
    return ec.generate_private_key(CURVE)


def sign(private_key: ec.EllipticCurvePrivateKey, message: bytes) -> bytes:
    return private_key.sign(message, ec.ECDSA(hashes.SHA256()))


def verify(public_key: ec.EllipticCurvePublicKey, signature: bytes, message: bytes) -> bool:
    try:
        public_key.verify(signature, message, ec.ECDSA(hashes.SHA256()))
        return True
    except InvalidSignature:
        return False


def ecdh(private_key: ec.EllipticCurvePrivateKey,
         peer_public_key: ec.EllipticCurvePublicKey) -> bytes:
    return private_key.exchange(ec.ECDH(), peer_public_key)


def derive_session_key(shared_secret: bytes, nonce_a: bytes, nonce_b: bytes,
                       hashchain_public: bytes, context: bytes) -> bytes:
    """Derive a 256-bit session key with HKDF-SHA512."""
    salt = sha512(nonce_a + nonce_b + hashchain_public)
    return HKDF(
        algorithm=hashes.SHA512(), length=32, salt=salt,
        info=b"BACP-IeFC/session-key/v1/" + context
    ).derive(shared_secret)


def random_nonce(size: int = 32) -> bytes:
    return secrets.token_bytes(size)
