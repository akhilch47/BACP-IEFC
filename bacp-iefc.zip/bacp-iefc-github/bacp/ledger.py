"""Small permissioned append-only ledger with a Proof-of-Authority validator set.

This is a deterministic local-chain emulator for reproducible experiments, not
an Ethereum client. The companion Solidity contract is provided separately.
"""
from __future__ import annotations
import hashlib
import json
import time
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Block:
    index: int
    timestamp: float
    validator: str
    transactions: tuple[dict[str, Any], ...]
    previous_hash: str
    block_hash: str


class PermissionedPoALedger:
    def __init__(self, validators: list[str] | None = None, batch_size: int = 100):
        self.validators = validators or ["fog-validator-1", "fog-validator-2"]
        if not self.validators:
            raise ValueError("At least one PoA validator is required")
        self.batch_size = batch_size
        self.pending: list[dict[str, Any]] = []
        self.blocks: list[Block] = []
        self.device_registry: dict[str, dict[str, Any]] = {}
        self.key_records: dict[tuple[str, str], dict[str, Any]] = {}
        self._validator_cursor = 0

    @staticmethod
    def _digest(payload: dict[str, Any]) -> str:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(encoded).hexdigest()

    @property
    def head_hash(self) -> str:
        return self.blocks[-1].block_hash if self.blocks else "0" * 64

    def submit(self, tx: dict[str, Any]) -> None:
        self.pending.append(tx)

    def commit(self, force: bool = False) -> Block | None:
        if not self.pending or (len(self.pending) < self.batch_size and not force):
            return None
        validator = self.validators[self._validator_cursor % len(self.validators)]
        self._validator_cursor += 1
        txs = tuple(self.pending[:self.batch_size])
        self.pending = self.pending[self.batch_size:]
        payload = {
            "index": len(self.blocks), "timestamp": time.time(),
            "validator": validator, "transactions": txs,
            "previous_hash": self.head_hash,
        }
        block = Block(**payload, block_hash=self._digest(payload))
        self.blocks.append(block)
        return block

    def register_device(self, device_id: str, public_key_hex: str, fog_id: str) -> None:
        if device_id in self.device_registry:
            raise ValueError(f"Device already registered: {device_id}")
        record = {"device_id": device_id, "public_key": public_key_hex, "fog_id": fog_id}
        self.device_registry[device_id] = record
        self.submit({"type": "REGISTER_DEVICE", **record})

    def get_device(self, device_id: str) -> dict[str, Any]:
        try:
            return self.device_registry[device_id]
        except KeyError as exc:
            raise KeyError(f"Unknown device: {device_id}") from exc

    def put_key_record(self, requester: str, recipient: str, public_key_hex: str,
                       fingerprint: str, expires_at: float) -> None:
        key = (requester, recipient)
        record = {
            "requester": requester, "recipient": recipient,
            "hashchain_public_key": public_key_hex,
            "fingerprint": fingerprint, "expires_at": expires_at,
        }
        self.key_records[key] = record
        self.submit({"type": "HASHCHAIN_KEY", **record})

    def get_valid_key_record(self, requester: str, recipient: str, now: float):
        record = self.key_records.get((requester, recipient))
        if record and record["expires_at"] > now:
            return record
        return None

    def verify_chain(self) -> bool:
        previous = "0" * 64
        for expected_index, block in enumerate(self.blocks):
            payload = {
                "index": block.index, "timestamp": block.timestamp,
                "validator": block.validator, "transactions": block.transactions,
                "previous_hash": block.previous_hash,
            }
            if block.index != expected_index or block.previous_hash != previous:
                return False
            if block.validator not in self.validators:
                return False
            if self._digest(payload) != block.block_hash:
                return False
            previous = block.block_hash
        return True

    def export(self) -> dict[str, Any]:
        return {
            "validators": self.validators,
            "blocks": [asdict(b) for b in self.blocks],
            "pending_transactions": self.pending,
            "registered_devices": self.device_registry,
            "key_records": [
                {"requester": k[0], "recipient": k[1], **v}
                for k, v in self.key_records.items()
            ],
        }
